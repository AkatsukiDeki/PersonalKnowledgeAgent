---
tags: [security, networking]
date: 2026-08-04
---
# Заметки по сетям
TCP/IP, OSI, BGP. 
Интересно, как устроены атаки типа Man-in-the-Middle. Нужно изучить Wireshark глубже.
